import torch.nn as nn


class MultiLayerPerceptron(nn.Module):

    def __init__(self, input_size):

        super(MultiLayerPerceptron, self).__init__()

        ######

        # 4.3 YOUR CODE HERE

        ######

    def forward(self, features):

        pass
        ######

        # 4.3 YOUR CODE HERE

        ######
